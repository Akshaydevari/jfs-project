import { Navigate } from 'react-router-dom';
import { useRole, UserRole } from '@/contexts/RoleContext';
import { useEffect, useState } from 'react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

const ProtectedRoute = ({ children, allowedRoles }: ProtectedRouteProps) => {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  const { hasAccess, role } = useRole();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Give context time to initialize
    setIsLoading(false);
  }, [role]);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Wait for role to be loaded from localStorage
  if (isLoading) {
    return null;
  }

  if (allowedRoles && !hasAccess(allowedRoles)) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
