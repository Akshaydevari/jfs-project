import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'admin' | 'inventory_manager';

interface RoleContextType {
  role: UserRole | null;
  setRole: (role: UserRole) => void;
  hasAccess: (allowedRoles: UserRole[]) => boolean;
  clearRole: () => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export const RoleProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole | null>(null);

  useEffect(() => {
    const savedRole = localStorage.getItem('userRole') as UserRole;
    if (savedRole) {
      setRoleState(savedRole);
    }
  }, []);

  const setRole = (newRole: UserRole) => {
    localStorage.setItem('userRole', newRole);
    setRoleState(newRole);
  };

  const clearRole = () => {
    localStorage.removeItem('userRole');
    setRoleState(null);
  };

  const hasAccess = (allowedRoles: UserRole[]) => {
    if (!role) return false;
    return allowedRoles.includes(role);
  };

  return (
    <RoleContext.Provider value={{ role, setRole, hasAccess, clearRole }}>
      {children}
    </RoleContext.Provider>
  );
};

export const useRole = () => {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within RoleProvider');
  }
  return context;
};
